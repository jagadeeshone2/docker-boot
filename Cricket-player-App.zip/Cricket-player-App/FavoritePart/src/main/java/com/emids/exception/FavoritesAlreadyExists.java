package com.emids.exception;

public class FavoritesAlreadyExists extends Exception {


	private String message;

	public FavoritesAlreadyExists() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FavoritesAlreadyExists(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public FavoritesAlreadyExists(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public FavoritesAlreadyExists(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FavoritesAlreadyExists(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "FavoritesAlreadyExists [message=" + message + "]";
	}
	
	
}
