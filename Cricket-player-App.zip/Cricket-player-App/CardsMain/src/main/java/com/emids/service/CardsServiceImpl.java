package com.emids.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.emids.entity.Cards;
import com.emids.exception.PlayerNotFound;
import com.emids.repository.CardsRepository;
import com.emids.responceEntityVo.Favorites;
import com.emids.responceEntityVo.Recommend;
import com.emids.responceEntityVo.ResponseEntityVo;

@Service
public class CardsServiceImpl implements CardsService {

	@Autowired
	private CardsRepository repo;

	@Autowired
	private RestTemplate template;

	@Override
	public List<Cards> findAllCards() {
		return repo.findAll();
	}

	@Override
	public Cards findByCardsId(long id) throws PlayerNotFound {
		Cards cards = null;
		Optional<Cards> optional = repo.findById(id);
		if (optional.isPresent()) {
			cards = optional.get();
		}
		if (!repo.existsById(id)) {
			throw new PlayerNotFound("PLAYER NOT FOUND...WRONG ID GIVEN");
		}
		return cards;
	}

	@Override
	public ResponseEntityVo getFavAndSave(long id) throws PlayerNotFound {
		Cards cards = null;
		Optional<Cards> optional = repo.findById(id);
		if (optional.isPresent()) {
			cards = optional.get();
		}
		if (!repo.existsById(id)) {
			throw new PlayerNotFound("PLAYER NOT FOUND...WRONG ID GIVEN");
		}
		Favorites favorites = new Favorites();
		favorites.setId(cards.getId());
		favorites.setFullName(cards.getFullName());
		favorites.setCountryName(cards.getCountryName());
		favorites.setImg(cards.getImg());
		favorites.setMajorTeam(cards.getMajorTeam());
		template.postForEntity("http://localhost:8222/fav/add", favorites, Favorites.class);
		ResponseEntityVo vo = new ResponseEntityVo();
		vo.setCards(cards);
		vo.setFavorites(favorites);
		return vo;

	}

	@Override
	public ResponseEntityVo getRecAndSave(long id) throws PlayerNotFound {
		Cards cards = null;
		Optional<Cards> optional = repo.findById(id);
		if (optional.isPresent()) {
			cards = optional.get();
		}
		if (!repo.existsById(id)) {
			throw new PlayerNotFound("PLAYER NOT FOUND...WRONG ID GIVEN");
		}
		Recommend recommend = new Recommend();

		recommend.setId(cards.getId());
		recommend.setFullName(cards.getFullName());
		recommend.setCountryName(cards.getCountryName());
		recommend.setImg(cards.getImg());
		recommend.setMajorTeam(cards.getMajorTeam());

		template.postForEntity("http://localhost:8333/rec/add", recommend, Recommend.class);
		ResponseEntityVo vo = new ResponseEntityVo();
		vo.setCards(cards);
		vo.setRecommend(recommend);
		return vo;
	}

	@Override
	public Cards findByFullName(String fullName) throws PlayerNotFound{
		Cards card = null;
		if (fullName == "") {
			throw new PlayerNotFound("Player Not found in Database");
		}
		card = repo.findByFullName(fullName);
		return card;
	}

}
