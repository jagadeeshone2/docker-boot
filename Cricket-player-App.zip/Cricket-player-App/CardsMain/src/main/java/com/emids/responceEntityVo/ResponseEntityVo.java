package com.emids.responceEntityVo;

import com.emids.entity.Cards;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResponseEntityVo {

	Cards cards;
	Favorites favorites;
	Recommend recommend;
}
