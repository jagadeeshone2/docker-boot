package com.emids.exception;

public class PlayerNotFound extends Exception{
	
	private String message;

	public PlayerNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PlayerNotFound(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public PlayerNotFound(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PlayerNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PlayerNotFound(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "PlayerNotFound [message=" + message + "]";
	}
	
}
